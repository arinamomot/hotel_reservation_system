package cvut.ear.hotelreservationsystem.model;

import cvut.ear.hotelreservationsystem.environment.Generator;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HotelTest {

//    @Test
//    public void addRoomWorksWhenAddingRoomForFirstTime() {
//        final Room room = Generator.generateRoom();
//        final Hotel hotel = Generator.generateHotel();
//        room.setId(Generator.randomInt());
//        hotel.setId(Generator.randomInt());
//
//        hotel.addRoom(room);
//
//        assertEquals(1, hotel.getRooms().size());
//    }
//
//    @Test
//    public void addRoomWorksWhenAddingRoomForNthTime() {
//        int numberOfRooms = 5;
//        final Hotel hotel = Generator.generateHotel();
//        hotel.setId(Generator.randomInt());
//
//        for (int i = 0; i < numberOfRooms; i++) {
//            final Room room = Generator.generateRoom();
//            room.setId(i);
//            hotel.addRoom(room);
//        }
//        assertEquals(numberOfRooms, hotel.getRooms().size());
//    }
//
//    @Test
//    public void removeRoomTest() {
//        final Room room = Generator.generateRoom();
//        final Hotel hotel = Generator.generateHotel();
//        room.setId(Generator.randomInt());
//        hotel.setId(Generator.randomInt());
//        hotel.addRoom(room);
//
//        hotel.removeRoom(room);
//        assertEquals(0, hotel.getRooms().size());
//    }
}