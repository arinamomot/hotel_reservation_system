package cvut.ear.hotelreservationsystem.model;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.*;

import cvut.ear.hotelreservationsystem.environment.Generator;

public class ReservationTest {

//    @Test
//    public void addRoomTest() {
//        final Room room = Generator.generateRoom();
//        final Reservation reservation = Generator.generateReservation();
//        room.setId(Generator.randomInt());
//        reservation.setId(Generator.randomInt());
//        reservation.addRoom(room);
//
//        assertEquals(1, reservation.getRooms().size());
//    }
//
//    @Test
//    public void removeRoomTest() {
//        final Room room = Generator.generateRoom();
//        final Reservation reservation = Generator.generateReservation();
//        room.setId(Generator.randomInt());
//        reservation.setId(Generator.randomInt());
//        reservation.addRoom(room);
//
//        reservation.removeRoom(room);
//        assertEquals(0, reservation.getRooms().size());
//    }
}