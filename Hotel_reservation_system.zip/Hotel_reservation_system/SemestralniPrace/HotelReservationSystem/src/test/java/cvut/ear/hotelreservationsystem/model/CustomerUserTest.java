package cvut.ear.hotelreservationsystem.model;

import cvut.ear.hotelreservationsystem.environment.Generator;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CustomerUserTest {

//    @Test
//    public void addReservationTest() {
//        final Reservation reservation = Generator.generateReservation();
//        final CustomerUser user = Generator.generateCustomerUser();
//        reservation.setId(Generator.randomInt());
//        user.setId(Generator.randomInt());
//        user.addReservation(reservation);
//
//        assertEquals(1, user.getReservations().size());
//    }
//
//    @Test
//    public void removeReservationTest(){
//        final Reservation reservation = Generator.generateReservation();
//        final CustomerUser user = Generator.generateCustomerUser();
//        reservation.setId(Generator.randomInt());
//        user.setId(Generator.randomInt());
//        user.addReservation(reservation);
//        user.removeReservation(reservation);
//        assertEquals(0, user.getReservations().size());
//    }
}
