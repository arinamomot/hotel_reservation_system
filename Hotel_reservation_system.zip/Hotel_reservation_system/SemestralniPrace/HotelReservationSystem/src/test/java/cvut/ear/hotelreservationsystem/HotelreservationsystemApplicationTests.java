package cvut.ear.hotelreservationsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelreservationsystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
